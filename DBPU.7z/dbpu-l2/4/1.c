void main()
{
asm (
" nop "
);
}