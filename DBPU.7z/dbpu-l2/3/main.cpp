#include <iostream>
int test() {;}
int main()
{
    //wywołanie funkcji test
    test();
}
