#include <stdio.h>

int main(void) {
	char str[180],str1[180],dane[180];
        printf("Podaj dane\n");
	fgets(dane, sizeof(dane), stdin);
	sprintf(str, "podano: %s",dane);
	puts(str);
        printf("Podaj dane\n");
      	fgets(dane, sizeof(dane), stdin);
	sprintf(str1, "podano: %s",dane); 
        puts(str1);
	return 0;
}
